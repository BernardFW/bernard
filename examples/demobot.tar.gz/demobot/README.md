Demobot
=======

This is a demo bot that provides a simple boilerplate to begin with. The goal
of this bot is just to say hi to the user and ask him how he's going.

You can see a walk-through of its code in the
[get started](../doc/get_started.md) section.
